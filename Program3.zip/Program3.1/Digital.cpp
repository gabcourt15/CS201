#include<iostream>
#include<iomanip>
#include "Digital.h"
using namespace std;


//Constructors
Digital::Digital()
{

}
Digital::Digital(int h, int m, int s)
{
	hour = h;
	minute = m;
	second = s;
}

//Functions
void Digital::SetAMPM()
{
	if (hour >= 12) //PM
	{
		time_of_day = 'P';
	}
	if (hour < 12) //AM
	{
		time_of_day = 'A';
	}
}

void Digital::Increment()
{
	second++;
	if (second == 60)
	{
		second = 0;
		minute++;
		if (minute == 60)
		{
			minute = 0;
			hour++;
		}
	}

}

void Digital::show()
{
	cout << "The time is " << setw(2) << setfill('0') << hour << ":" << setw(2) << setfill('0') << minute << ":" << setw(2) << setfill('0') << second << time_of_day;
}