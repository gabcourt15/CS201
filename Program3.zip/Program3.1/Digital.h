#pragma once
#include "Clock.h"
#include<string>

class Digital:public Clock {
public:
	Digital();
	Digital(int h, int m, int s);
	void SetAMPM();
	void Increment();
	void show();
	char time_of_day;

};