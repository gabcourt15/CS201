#pragma once

class Clock {
public:
	Clock();
	Clock(int h, int m, int s);
	int getHour();
	int getMinute();
	int getSecond();
	void setHour(int x);
	void setMinute(int x);
	void setSecond(int x);
	void show();
protected:
	int hour;
	int minute;
	int second;
};