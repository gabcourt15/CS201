#include "Clock.h"
#include<iostream>
#include<iomanip>
using namespace std;
//Constructor
Clock::Clock()
{

}
Clock::Clock(int h, int m, int s)
{
	hour = h;
	minute = m;
	second = s;
}

//Getters
int Clock::getHour()
{
	return hour;
}

int Clock::getMinute()
{
	return minute;
}

int Clock::getSecond()
{
	return second;
}

//Setters
void Clock::setHour(int x)
{
	hour = x;
}

void Clock::setMinute(int x)
{
	minute = x;
}

void Clock::setSecond(int x)
{
	second = x;
}

//functions
void Clock::show()
{
	cout << "The time is " << setw(2)<< setfill('0')<< hour << ":" << setw(2) << setfill('0')<< minute << ":" << setw(2) << setfill('0') << second << ".\n";
}