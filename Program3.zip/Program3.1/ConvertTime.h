#pragma once
#include"Digital.h"

class ConvertTime:public Digital {
public:
	ConvertTime();
	ConvertTime(int h, int m, int s);
	void show();
	void timer();

};