#include "ConvertTime.h"
#include<iostream>
#include<iomanip>
#include<ctime>
using namespace std;

//Constructor
ConvertTime::ConvertTime()
{

}
ConvertTime::ConvertTime(int h , int m , int s)
{
	hour = h;
	minute = m;
	second = s;
}

//Functions
void ConvertTime::show()
{
	hour += 5;
	cout << "\nThe time in GMT is " << setw(2) << setfill('0') << hour << ":" << setw(2) << setfill('0') << minute << ":" << setw(2) << setfill('0') << second << endl;
}

void ConvertTime::timer()
{
	bool choice = true;
	int answer;
	while (choice == true) //while setting timer
	{
		bool small_loop = true;
		int timer_minute = 0;
		int timer_second = 0;
		bool loop = true;
		time_t now;
		struct tm nowlocal;
		now = time(NULL);
		localtime_s(&nowlocal, &now);
		cout << "The current time is " << setw(2) << setfill('0') << nowlocal.tm_hour << ":" << setw(2) << setfill('0') << nowlocal.tm_min << ":" << setw(2) << setfill('0') << nowlocal.tm_sec << ".\n";
		timer_minute = nowlocal.tm_min + 2; //add two to current minutes
		timer_second = nowlocal.tm_sec;
		if (timer_minute >= 60)
		{
			timer_minute = timer_minute % 60;
		}
		while (loop)
		{
			time_t now;
			struct tm nowlocal;
			now = time(NULL);
			localtime_s(&nowlocal, &now);
			if (timer_minute == nowlocal.tm_min) //timer current minute = current minute
			{
				if (timer_second == nowlocal.tm_sec) //timer current second = current second
				{
					cout << "2 minutes is up.  The time is  now " << setw(2) << setfill('0') << nowlocal.tm_hour << ":" << setw(2) << setfill('0') << nowlocal.tm_min << ":" << setw(2) << setfill('0') << nowlocal.tm_sec << ".\n";
					loop = false;
				}
			}
			
		}
		while (small_loop == true) // choice loop
			{
				cout << "Would you like to set another timer? Enter 1 for yes, 2 for no.";
				cin >> answer;
				if (answer == 2)
				{
					small_loop = false;
					choice = false;
				}
				else if (answer == 1)
				{
					small_loop = false;
					choice = true;
				}
				else
				{
					cout << "You must enter 1 or 2.";
				}


			}
	}
}