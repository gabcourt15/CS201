//Gabby Courtney
//Program 3
//Due 10/9/16

//File inclusion
#include "Clock.h"
#include "Digital.h"
#include "ConvertTime.h"

#include<iostream>
#include<string>
using namespace std;
//Declaring variables
Digital Time;
ConvertTime Time2;
int hour, minute, second, err;
bool hour_loop = true, minute_loop = true, second_loop = true;

void main()
{
	while (hour_loop == true)
	{
		try
		{
			cout << "Enter the hour";
			cin >> hour;
			if (hour <= 0 || hour > 24) //0 is not a correct input for hour, and hours cannot go over 24
			{
				throw err;
			}
			else if (hour > 0 && hour <= 23) // correnc input
			{
				hour_loop = false;
			}
		}
		catch (int err) //catch error of bad input
		{
			cout << "You must enter a valid hour\n";
		}
	}
	while (minute_loop == true)
	{
		try
		{
			cout << "Enter the minute";
			cin >> minute;
			if (minute < 0 || minute > 59) //you cannot have negative minutes or more than 59
			{
				throw err;
			}
			else if (minute >= 0 && minute <= 59) //correct input
			{
				minute_loop = false;
			}
		}
		catch (int err) //catch error of bad input
		{
			cout << "You must enter a valid minute.\n";
		}
	}
	while (second_loop == true)
	{
		try
		{
			cout << "Enter the second";
			cin >> second;
			if (second < 0 || second > 59) //you cannot have negative seconds or more than 59
			{
				throw err;
			}
			else if (second >= 0 && second <= 59) //correct input
			{
				second_loop = false;
			}
		}
		catch (int err) //catch errors from bad input
		{
			cout << "You must enter a valid time.\n";
		}
	}
	Time = Digital(hour, minute, second);
	Time.SetAMPM();
	Time.show();
	Time.Increment();
	cout << endl;
	Time.show();
	Time2 = ConvertTime(hour, minute, second);
	Time2.show();
	Time2.timer();
}

