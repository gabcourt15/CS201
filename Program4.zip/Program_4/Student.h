#pragma once
#include<string>
#include<fstream>
#include<iostream>
using namespace std;

class Student {
public:
	//Constructor
	Student(string first = " ", string last= " ", unsigned int ID = 0);
	//Destructor
	~Student();
	//Copy Constructor
	Student(const Student& obj);
	//Assignment Operator
	const Student& operator=(const Student& obj);
	//Getters
	unsigned int getID();
	string getFirst();
	string getLast();
	//Setters
	void setID(unsigned int x);
	void setFirst(string f);
	void setLast(string l);
	void setNumItems(unsigned int x);
	//Functions
	void Clear();
	bool CheckOut(const string& item);
	int CheckoutCount();
	bool CheckIn(const string& item, int studentArraySize, Student* studentArray);
	bool HasCheckedOut(const string& item);
	int resizeArray(string* &oldArray, int oldSize);
	//stream overloading
	friend istream& operator >> (istream& in, Student& item);
	friend ostream& operator <<(ostream& out, const Student& item);
	//Operator overloading
	Student& operator+(const string& item);
	void operator+=(const string& item);
	bool operator==(Student& rhs);
	bool operator!=(Student& rhs);
private:
	string first, last; 
	unsigned int ID, num_items_out, array_size, add_items; 
	string* items_out;
};