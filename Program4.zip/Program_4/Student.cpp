#include"Student.h"
using namespace std;

Student::Student(string first, string last, unsigned int ID)
{
	first = first;
	last = last;
	ID = ID;
	items_out = nullptr;
	num_items_out = 0;
	array_size = 0;
}

Student::~Student()
{
	delete[] items_out;
	items_out = nullptr;
}

Student::Student(const Student& obj)
{
	*this = obj;
}

const Student& Student::operator=(const Student& obj)
{
	if (this != &obj)
	{
		this->~Student();//delete dynamic data
		first = obj.first; //copy over data
		last = obj.last;
		ID = obj.ID;
		num_items_out = obj.num_items_out;
		array_size = obj.array_size;
		if (num_items_out != 0)
		{
			items_out = new string[array_size];//create new dynamic array
			for (int i = 0; i < num_items_out; i++)//populate array with data
			{
				items_out[i] = obj.items_out[i];
			}
		}
		return *this;
	}
}
unsigned int Student::getID()
{
	return ID;
}

string Student::getFirst()
{
	return first;
}

string Student::getLast()
{
	return last;
}

void Student::setID(unsigned int x)
{
	if (x > 1000 || x < 10000)
	{
		ID = x;
	}

}

void Student::setFirst(string f)
{
	first = f;
}

void Student::setLast(string l)
{
	last = l;
}

void Student::setNumItems(unsigned int x)
{
	num_items_out = x;
}

void Student::Clear()
{
	first = " ";
	last = " ";
	ID = 0;
	num_items_out = 0;
	array_size = 0;
	Student::~Student();
}

bool Student::CheckOut(const string& item)
{
	if (items_out == nullptr || array_size == 0) //if array is empty or array size = 0 create array
	{
		array_size = 5;
		items_out = new string[array_size];
		items_out[num_items_out] = item;
		num_items_out++;
	}
	for (int i = 0; i < num_items_out; i++) //checks to see if item has already been checked out
	{
		if (items_out[i] == item)
		{
			return false;
		}
	}
	if ((num_items_out + 1) > array_size) //checks to see if array needs to be resized
	{
		array_size = resizeArray(items_out, array_size);
	}
	items_out[num_items_out] = item; //adds item to arrya
	num_items_out++;
	return true;
}

int Student::CheckoutCount()
{
	return num_items_out;
}

bool Student::CheckIn(const string& item, int studentArraySize, Student* studentArray)
{
	for (int i = 0; i < studentArraySize; i++)
	{
		if (studentArray[i].HasCheckedOut(item) == true) //if studdent has item checked out
		{
			for (int i = 0; i < num_items_out; i++) //find item in items array
			{
				if (items_out[i] == item)
				{
					items_out[i] = "";
					num_items_out--;
					if (num_items_out == 0)//if array is empty
					{
						Student::~Student();//delete it
					}
					return true;
				}
			}
		}
	}
		return false;
}

bool Student::HasCheckedOut(const string& item)
{
	for (int i = 0; i < num_items_out; i++)//for item in array
	{
		if (items_out[i] == item) //if item matches target item
		{
			return true; //student has this item checked out
		}
	} 
	return false;//student doesnt have this item checkedout
}

int Student::resizeArray(string* &oldArray, int oldSize) //resizes array
{
	int newSize = oldSize * 2;
	string* newArray = new string[newSize];
	for (int i = 0; i < oldSize; i++)
	{
		newArray[i] = oldArray[i];
	}
	delete[] oldArray;
	oldArray = newArray;
	return newSize;
}




istream & operator >> (istream & in, Student & item)
{
	
	item.Clear();
	in >> item.ID >> item.first >> item.last >> item.add_items;
	if (item.add_items != 0)
	{
		string ITEM;
		for (int i = 0; i < item.add_items; i++)
		{
			in >> ITEM;
			item.CheckOut(ITEM);
		}
	}
	return in;
}

ostream & operator << (ostream& out, const Student& item)
{
	if (item.num_items_out != 0)
	{
		out << item.ID << " " << item.first << " " << item.last << endl << item.num_items_out;
		if (item.num_items_out > 0)
		{
			for (int i = 0; i <= item.num_items_out + 1; i++)
			{
				if (item.items_out[i] != "")
					out << item.items_out[i] << endl;
			}
		}
		out << endl;
	}	return out;
}

Student & Student::operator+(const string & item)
{
	CheckOut(item);
	return *this;
}

void Student::operator+=(const string & item)
{
	CheckOut(item);
}

bool Student::operator==(Student & rhs)
{
	if (ID == rhs.getID())
		return true;
	else
		return false;
}

bool Student::operator!=(Student & rhs)
{
	if (ID == rhs.getID())
		return false;
	else
		return true;
}