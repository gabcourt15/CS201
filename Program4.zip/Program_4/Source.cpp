#include"Student.h"
using namespace std;

void main() {
	//declaring variables
	Student stu;
	int students = 0;
	int size = 5;
	Student* studentArray = new Student[size];
	//declaring functions
	int resizeArray(Student* &oldArray, int oldSize);
	//file streams
	ifstream Students;
	ifstream Checkouts;
	ifstream Checkins;
	ofstream update;

	//opening files
	Students.open("students.txt");
	Checkouts.open("checkouts.txt");
	Checkins.open("checkins.txt");
	update.open("updatedStudents.txt");

	//checking if files opened correctly
	if (Students.fail())
	{
		cout << "File was not able to open.";
		exit(1);
	}
	if (Checkouts.fail())
	{
		cout << "File was not able to open.";
		exit(1);
	}
	if (Checkins.fail())
	{
		cout << "File was not able to open.";
		exit(1);
	}
	if (update.fail())
	{
		cout << "File was not able to open.";
		exit(1);
	}

	//Read in students txt and create student objects
	while (Students.good())
	{
		Students >> stu;
 		if ((students + 1) > size)
		{
			size = resizeArray(studentArray, size);
		}
		studentArray[students] = stu;
		students++;
	}
	Students.close();
	//Read in ID and item to check out
	while (Checkouts.good())
	{
		string targetItem;
		unsigned int targetID;
		Checkouts >> targetID;
		Checkouts >> targetItem;
		for (int i = 0; i < size; i++)
		{
			if (studentArray[i].getID() == targetID) //if student array ID matches target ID
			{
				studentArray[i].CheckOut(targetItem); //checkout item
			}
		}
	}
	Checkouts.close();
	//Read in item and  check in
	while (Checkins.good())
	{
		string targetItem;
		Checkins >> targetItem;
		for (int i = 0; i < size; i++)
		{
			if (studentArray[i].HasCheckedOut(targetItem) == true) //if student has item checked out
			{
				studentArray[i].CheckIn(targetItem, size, studentArray); //check in item
			}
		}
	}
	Checkins.close();
	for (int i = 0; i < students; i++) //loop to output students to output file
	{
		update << studentArray[i];
	}
	update.close();
}

int resizeArray(Student* & oldArray, int oldSize)
{
	int newSize = oldSize * 2;
	Student* newArray = new Student[newSize];
	for (int i = 0; i < oldSize; i++)
	{
		newArray[i] = oldArray[i];
	}
	delete[] oldArray;
	oldArray = newArray;
	return newSize;
}