#include"Patient.h"
#include"Queue.h"
#include<string>
using namespace std;

//Declaring functions
int MainMenu();
int SubMenu(string d);

void main()
{
	//declaring variables
	bool loop1 = true, loop2 = true, loop5 = true;
	Queue heart, heartc, plastic, plasticc, lung, lungc;
	int choice1, choice2, queueSize, social, condition;
	string department, fname, lname;

	while (loop1)
	{
		choice1 = MainMenu(); //display main menu
		system("cls");
		loop2 = true;
		if (choice1 == 1) //heart clinic
		{
			department = "Heart Clinic";
			while (loop2)
			{
				choice2 = SubMenu(department); //display sub menu
				if (choice2 == 1) //add regular patient
				{
					queueSize = heart.size() + heartc.size(); //makes sure queue does not have more than 100 patients
					if (queueSize < 100)
					{
						cout << "Enter Patient SSN: ";
						cin >> social;
						cout << "Enter Patient Last Name: ";
						cin >> lname;
						cout << "Enter Patient First Name: ";
						cin >> fname;
						heart.addPatient(social, fname, lname); //add patient to queue
						cout << "The patient has been added to the queue.\n";
						system("pause");
						system("cls");
					}
					else //error message
					{
						cout << "Sorry, we cannot currently accept any new patients.\n";
					}
				}
				else if (choice2 == 2) //add critical patient
				{
					queueSize = heart.size() + heartc.size(); //make sure queue does not have more than 100 patients
					if (queueSize < 100)
					{
						cout << "Enter Patient SSN: ";
						cin >> social;
						cout << "Enter Patient Last Name: ";
						cin >> lname;
						cout << "Enter Patient First Name: ";
						cin >> fname;
						heartc.addPatient(social, fname, lname); //add patient to critical queue
						cout << "The patient has been added to the queue.\n";
						system("pause");
						system("cls");
					}
					else //error message
					{
						cout << "Sorry, we cannot currently accept any new patients.\n";
					}
				}
				else if (choice2 == 3) //Take patient to operation
				{
					if (!heartc.is_empty()) //if there is someone in critical condidtion take them to operation first
					{
						heartc.RemovePatient(); //remove patient from queue
						cout << "Patient has been removed for operation.\n";
						system("pause");
						system("cls");

					}
					else if (!heart.is_empty()) //if no one is in critical condition but there is someone in regular condition
					{
						heart.RemovePatient(); //remove patient from queue
						cout << "Patient has been removed for operation.\n";
						system("pause");
						system("cls");
					}
					else //error message
					{
						cout << "There are no patients to operate on.\n";
					}
				}
				else if (choice2 == 4) //remove patient
				{
					cout << "Enter the SSN of Patient to be Removed\n";
					cin >> social;
					cout << "Looking in Critical Queue for Patient\n";
					heartc.cancelPatient(social); //remove patient from critical queue if there
					cout << "Looking in Regular Queue for Patient\n";
					heart.cancelPatient(social); //remcove patitent from regular queue if there
					cin.ignore();
					cin.clear();
					system("pause");
					system("cls");
				}
				else if (choice2 == 5) //display queues
				{
					cout << "The Critical Queue contains the following patients \n";
					heartc.Print();
					cout << "\nThe Regular Queue contains the following patients.\n";
					heart.Print();
					system("pause");
					system("cls");
				}
				else if (choice2 == 6) //return to main menu
				{
					cout << "Returning to Main Menu.\n";
					loop2 = false;

				}
			}
		}
		else if (choice1 == 2)//lung clinic
		{
			department = "Lung Clinic";
			while (loop2)
			{
				choice2 = SubMenu(department); //display department menu
				if (choice2 == 1)
				{
					queueSize = lung.size() + lungc.size(); //makes sure the queue does not have more than 100 patients
					if (queueSize < 100)
					{
						cout << "Enter Patient SSN: ";
						cin >> social;
						cout << "Enter Patient Last Name: ";
						cin >> lname;
						cout << "Enter Patient First Name: ";
						cin >> fname;
						lung.addPatient(social, fname, lname); //add patient
						cout << "The patient has been added to the queue.\n";
						system("pause");
						system("cls");
					}
					else //error message
					{
						cout << "Sorry, we cannot currently accept any new patients.\n";
					}
				}
				else if (choice2 == 2)//add critical patient
				{
					queueSize = lung.size() + lungc.size();//makes sure the queue does not have more than 100 patients
					if (queueSize < 100)
					{
						cout << "Enter Patient SSN: ";
						cin >> social;
						cout << "Enter Patient Last Name: ";
						cin >> lname;
						cout << "Enter Patient First Name: ";
						cin >> fname;
						lungc.addPatient(social, fname, lname); //add patient to critical queue
						cout << "The patient has been added to the queue.\n";
						system("pause");
						system("cls");
					}
					else //error message
					{
						cout << "Sorry, we cannot currently accept any new patients.\n";
					}
				}
				else if (choice2 == 3) //remove patient for operation
				{
					if (!lungc.is_empty()) //checks critical queue for patient
					{
						lungc.RemovePatient();
						cout << "Patient has been removed for operation.\n";
						system("pause");
						system("cls");

					}
					else if (!lung.is_empty()) //checks regular queue for patient
					{
						lung.RemovePatient();
						cout << "Patient has been removed for operation.\n";
						system("pause");
						system("cls");
					}
					else //error message
					{
						cout << "There are no patients to operate on.\n";
					}
				}
				else if (choice2 == 4)//remove patient
				{
					cout << "Enter the SSN of Patient to be Removed\n";
					cin >> social;
					cout << "Looking in Critical Queue for Patient\n";
					lungc.cancelPatient(social);
					cout << "Looking in Regular Queue for Patient\n";
					lung.cancelPatient(social);
					cin.ignore();
					cin.clear();
					system("pause");
					system("cls");
				}
				else if (choice2 == 5) //display queues
				{
					cout << "The Critical Queue contains the following patients \n";
					lungc.Print();
					cout << "\nThe Regular Queue contains the following patients.\n";
					lung.Print();
					system("pause");
					system("cls");
				}
				else if (choice2 == 6) //exits to main menu
				{
					cout << "Returning to Main Menu.\n";
					loop2 = false;

				}
			}
		}
		else if (choice1 == 3)//plastic surgery
		{
			department = "Plastic Surgery";
			while (loop2)
			{
				choice2 = SubMenu(department); //displays deptmenu
				if (choice2 == 1) //add regular patient
				{
					queueSize = plastic.size() + plasticc.size(); //makes sure the queue doesnt have more than 100 patients
					if (queueSize < 100)
					{
						cout << "Enter Patient SSN: ";
						cin >> social;
						cout << "Enter Patient Last Name: ";
						cin >> lname;
						cout << "Enter Patient First Name: ";
						cin >> fname;
						plastic.addPatient(social, fname, lname); //add patient to queue
						cout << "The patient has been added to the queue.\n";
						system("pause");
						system("cls");
					}
					else //error message
					{
						cout << "Sorry, we cannot currently accept any new patients.\n";
					}
				}
				else if (choice2 == 2)//add critical patient
				{
					queueSize = plastic.size() + plasticc.size(); //makes sure the queue doesnt have more than 100 patients
					if (queueSize < 100)
					{
						cout << "Enter Patient SSN: ";
						cin >> social;
						cout << "Enter Patient Last Name: ";
						cin >> lname;
						cout << "Enter Patient First Name: ";
						cin >> fname;
						plasticc.addPatient(social, fname, lname); //add citical patient
						cout << "The patient has been added to the queue.\n";
						system("pause");
						system("cls");
					}
					else //error message
					{
						cout << "Sorry, we cannot currently accept any new patients.\n";
					}
				}
				else if (choice2 == 3)//take patient to operation
				{
					if (!plasticc.is_empty()) //checks for patient in critical queue
					{
						plasticc.RemovePatient();
						cout << "Patient has been removed for operation.\n";
						system("pause");
						system("cls");

					}
					else if (!plastic.is_empty()) //checks for patient in regular queue
					{
						plastic.RemovePatient();
						cout << "Patient has been removed for operation.\n";
						system("pause");
						system("cls");
					}
					else //error message
					{
						cout << "There are no patients to operate on.\n";
					}
				}
				else if (choice2 == 4) //remove patient
				{
					cout << "Enter the SSN of Patient to be Removed\n";
					cin >> social;
					cout << "Looking in Critical Queue for Patient\n";
					plasticc.cancelPatient(social);
					cout << "Looking in Regular Queue for Patient\n";
					plastic.cancelPatient(social);
					cin.ignore();
					cin.clear();
					system("pause");
					system("cls");
				}
				else if (choice2 == 5) //displays queues
				{
					cout << "The Critical Queue contains the following patients \n";
					plasticc.Print();
					cout << "\nThe Regular Queue contains the following patients.\n";
					plastic.Print();
					system("pause");
					system("cls");
				}
				else if (choice2 == 6) //returns to main menu
				{
					cout << "Returning to Main Menu.\n";
					loop2 = false;

				}
			}
		}
		else if (choice1 == 4)//exit
		{
			cout << "See you next time....\n";
			system("pause");
			loop1 = false;
		}
		else //incorrect input
		{
			system("cls");
			cout << "Sorry, that is incorrect input.  Please enter a number 1 - 4.\n.";
		}

	}
}

int MainMenu()
{
	bool loop3 = true;
	int num;
	while (loop3)
	{
		cout << "Welcome to Starling City Hospital! " << endl;
		cout << "Which department would you like to visit?" << endl;
	 	cout << "1: Heart Clinic" << endl;
		cout << "2: Lung Clinic" << endl;
		cout << "3: Plastic Surgery" << endl;
		cout << "4: Exit" << endl << endl;
		cout << "Please Enter Your Choice:" << endl;
		cin >> num;
		if (num >= 1 && num <= 4) //catches correct input
		{
			loop3 = false;
			return num;
			system("cls");
		}
		else //catches incorrect input
		{
			system("cls");
			cout << "Please enter the number of the department you would like to select.\n";
		}
	}
}

int SubMenu(string d)
{
	int num;
	bool loop4 = true;
	
	while (loop4)
	{
		cout << "Welcome to the " << d << "." << endl;
		cout << "What would you like to do?" << endl;
		cout << "1: Add Patient" << endl;
		cout << "2: Add Critical Patient" << endl;
		cout << "3: Take Patient to Operation" << endl;
		cout << "4: Cancel Patient" << endl;
		cout << "5: List Queue of Patients" << endl;
		cout << "6: Return to Main Menu" << endl;
		cin >> num;
		if (num >= 1 && num <= 6) //catches correct input
		{
			loop4 = false;
			system("cls");
			return num;
		}
		else //catches incorrect input
		{
			system("cls");
			cout << "Please enter the number of the action you would like to select.\n";
		}
	}
}