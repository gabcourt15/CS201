#include"Queue.h"
#include"Patient.h"
using namespace std;

Queue::Queue()
{
	head = tail = nullptr;
	cnt = 0;
}

int Queue::size() const
{
	return cnt;
}

void Queue::addPatient(const int& SSN, const string& first, const string& last)
{
	if (is_empty())
	{
		head = new Patient(SSN, first, last, nullptr);
		tail = head;
		cnt++;
	}
	else
	{
		tail->next = new Patient(SSN, first, last, nullptr);
		tail = tail->next;
		cnt++;
	}
}

void Queue::EmptyQueue()
{
	Patient* p;
	p = head;
	while (head != nullptr)
	{
		p = head;
		head = head->next;
		delete p;
	}
	tail = nullptr;
	cnt = 0;
}

void Queue::cancelPatient(const int & SSN)
{
	if (is_empty())
	{
		cout << "The Queue is empty, you cannot cancel any patients.\n";
	}
	else
	{
		Patient *temp;
		Patient *target;
		temp = head;
		if (temp->ssn == SSN)
		{
			head = head->next;
			if (head == nullptr)
			{
				tail = nullptr;
			}
			delete temp;
			cnt--;
			cout << "The patient with SSN: " << SSN << " has been deleted.\n\n";
		}
		else
		{
			target = temp;
			while (target != nullptr)
			{
				temp = target;
				target = target->next;
				if (target != nullptr)
				{
					if (target->ssn == SSN)
					{
						temp->next = target->next;
						cout << "The patient with SSN: " << target->ssn << "has been deleted.\n\n";
						delete target;
						cnt--;
					}
				}
				else
				{
					cout << "The patient with SSN " << SSN << " was not found.\n\n";
				}
			}
		}
	}
}

bool Queue::is_empty() const
{
	return (head == nullptr);
}

void Queue::Print()
{
	if (is_empty())
	{
		cout << "The Queue is empty.\n";
	}
	else
	{
		Patient *p;
		p = head;
		while (p != nullptr)
		{
			cout << p->lname << ", " << p->fname << " SSN: " << p->ssn << endl;
			p = p->next;
		}
	}
}

bool Queue::SearchQueue(int SSN)
{
	Patient *p;
	p = head;
	while (p != nullptr)
	{
		if (p->ssn == SSN)
		{
			return true;
		}
		p = p->next;
	}
	return false;
}

void Queue::RemovePatient()
{
	if (is_empty())
	{
		cout << "There are currently no patients.\n";
	}
	else
	{
		Patient *temp;
		temp = head;
		head = head->next;
		if (head == nullptr)
		{
			tail = nullptr;
		}
		delete temp;
		cnt--;
	}
}

