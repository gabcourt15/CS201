
#pragma once
#include<string>
#include<iostream>
using namespace std;

struct Patient
{
	Patient() { next = NULL; }
	Patient(int SSN, string first, string last, Patient* link) { ssn = SSN; fname = first; lname = last; next = link; }
	string fname;
	string lname;
	int ssn;
	Patient* next;

};