#pragma once
#include<string>
#include<iostream>
#include"Patient.h"
using namespace std;

class Queue {
public:
	//Constructor
	Queue();
	//functions
	int size() const;
	void addPatient(const int& SSN,const string& first, const string& last);
	void EmptyQueue();
	void cancelPatient(const int& SSN);
	bool is_empty() const;
	void Print();
	bool SearchQueue(int SSN);
	void RemovePatient();
private:
	Patient *head, *tail;
	int cnt;

};
