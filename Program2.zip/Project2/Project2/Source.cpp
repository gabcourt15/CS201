//Gabby Courtney
//Program 2
//9/25/2016

#include<string>
#include<cmath>
#include<fstream>
#include<iostream>
#include "DeptStoreMember.h"
using namespace std;

//declaring variables
DeptStoreMember memberArray[100];
int counter = 0, ID, num_purchases, ID_index;
string buyer_name;
double price, undiscounted_price, before_discount_price, discounted_price, reward_cash;

//declaring functions
void ReadPurchaseInfo(ifstream &filename);
//PreCondition: Takes file to read data
//PostCondition: Outputs totals
int LinearSearch_ID(int x);
//PreCondition:Takes and int x and compares to other ints
//PostCondition: Finds the same int x and returns the index of matching pair
double UndiscountedPrice(int x, ifstream &filename);
//PreCondition: takes int x and file to read prices
//PostCondition: calculates undiscounted price

//main program
void main()
{
	//Create DeptCustomers.txt input file stream
	ifstream CustomerList;
	
	//Opening DeptCustomers.txt
	CustomerList.open("DeptCustomers.txt");

	if (CustomerList.fail())//if file cannot be opened
	{
		cout << "The file could not be opened";
		system("Pause");
		exit(1);
	}
	while (memberArray[counter].ReadData(CustomerList) && (counter < 100))// add each member to array
	{
		counter++;
	}
	
	//close file
	CustomerList.close();

	//Create Purchases.txt input file stream
	ifstream PurchasesList;

	//Opening Purchases.txt
	PurchasesList.open("Purchases.txt");
	
	if (PurchasesList.fail())//if file cannot be opened
	{
		cout << "The file could not be opened";
		system("Pause");
		exit(1);
	}

	while (PurchasesList.good()) //while file can be read
	{
		ReadPurchaseInfo(PurchasesList);
	}
	system("Pause");
	PurchasesList.close();//close file

}


//function definitions

void ReadPurchaseInfo(ifstream &filename)
{
	filename >> ID; //read in ID
	ID_index = LinearSearch_ID(ID); //Find ID in member array
	filename >> num_purchases; //read in number of purchases made by member
	before_discount_price = UndiscountedPrice(num_purchases, filename); //calculate undiscounted price
	discounted_price = memberArray[ID_index].DiscountedPrice(before_discount_price); //calculate discounted price
	reward_cash = memberArray[ID_index].RewardCash(discounted_price);//calculate reward dollars earned
	cout << memberArray[ID_index].FullName(); //output name
	cout << endl << "Your original undiscounted price was " << before_discount_price << ". \nYour discounted price is " << discounted_price << ". \nYou have earned " << reward_cash << " dollars in reward cash. \n"; //output prices
	if (reward_cash >= 5.00) //if reward dollars can be used
	{
		cout << "You can use your rewards.\n\n";
	}
	else // else reward dollars cannot be used
	{
		cout << "You cannot use your rewards.  Keep saving.\n\n";
	}

}

int LinearSearch_ID(int x) // search member array using linear search for ID
{
	for (int i = 0; i < 100; i++)
	{
		if (memberArray[i].GetID() == x) //if ID of member in array matches ID in purchase list
		{
			return i; //return index of member in array
		}
		else
		{
			continue; //keep searching for matching pair
		}
	}
	return -1; //if cannot be found, return -1
}

double UndiscountedPrice(int x, ifstream &filename) //calculates undiscounted price
{
	double undiscounted_price = 0;
	for (int i = 0; i < x; i++)
	{
		filename >> price;
		undiscounted_price += price;
	}
	return undiscounted_price;
}