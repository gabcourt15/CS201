#include "DeptStoreMember.h"

DeptStoreMember::DeptStoreMember()
{

}

DeptStoreMember::DeptStoreMember(int x, string fname, string lname)
{
	if (x>0)
	{ 
		ID = x;
	}
	else
	{
		ID = -1;
	}
	
	firstname = fname;
	lastname = lname;
}

int DeptStoreMember::GetID()
{
	return ID;
}

void DeptStoreMember::SetID(int x)
{
	ID = x;
}

string DeptStoreMember::GetFirstName()
{
	return firstname;
}

void DeptStoreMember::SetFirstName(string x)
{
	firstname = x;
}

string DeptStoreMember::GetLastName()
{
	return lastname;
}

void DeptStoreMember::SetLastName(string x)
{
	lastname = x;
}

string DeptStoreMember::FullName()
{
	return lastname + ", " + firstname;
}

bool DeptStoreMember::ReadData(ifstream &CustomerList)
{
	int N;
	CustomerList >> N;
	if (CustomerList.good())
	{
		SetID(N);
		CustomerList >> firstname >> lastname >> N;
		num_of_purchases = N;
		for (int i = 0; i < num_of_purchases; i++)
		{
			CustomerList >> outstanding_prices[i];
		}
	}
	return CustomerList.good();
}

double DeptStoreMember::DiscountedPrice(double price)
{
	return price * .95;
}

double DeptStoreMember::RewardCash(double price)
{
	return price * .01;
}
