#include<string>
#include<fstream>
using namespace std;
#pragma once


class DeptStoreMember
{
public:
	//Constructors
	DeptStoreMember();
	DeptStoreMember(int x, string fname, string lname);

	//Getters and Setters
	int GetID();
	void SetID(int x);
	string GetFirstName();
	void SetFirstName(string x);
	string GetLastName();
	void SetLastName(string x);
	string FullName();
	
	//Input
	bool ReadData(ifstream &fin);
	
	//calculation functions
	double DiscountedPrice(double price);
	double RewardCash(double price);
	
private:
	int ID, num_of_purchases;
	string firstname, lastname, fullname;
	double outstanding_prices[10];

};
