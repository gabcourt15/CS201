#include<iostream>
#include<string>
using namespace std;


//declaring functions
int search(int numturns, int currenttokens, int targettokens);


void main()
{
	//declaring variables
	int turns;
	int tokens;
	int target_tokens;
	int turns_left;
	bool run_again = true;
	string answer;

	while (run_again == true)
	{
		tokens = 13;
		cout << "Enter the number of tokens you want to reach:" << endl;
		cin >> target_tokens;
		cout << endl << "What is the number of turns?" << endl;
		cin >> turns;
		cout << endl << "Searching for a solution within " << turns << " moves...." << endl;
		search(turns, tokens, target_tokens);
		cout << "Would you line to try again? [Y/N]";
		cin >> answer;
		if (answer == "N" || answer == "n")
		{
			run_again = false; //causes while loop to stop
		}
	}
}



//defining functions
int search(int numturns, int currenttokens, int targettokens)
{
	if (numturns == 0) //if we have run out of turns
	{
		cout << "No valid path could be found." << endl;
		return 0;
	}
	if (currenttokens < targettokens && currenttokens % 2 != 0)
	{
		currenttokens += 25;
		cout << "By adding 25, you get " << currenttokens << "." << endl;
		numturns--;
		if (currenttokens == targettokens) //if solution has been found
		{
			cout << "Path found with " << numturns << " turns left." << endl;
			return 0;
		}
		else //if solution has not been found
		{
			search(numturns, currenttokens, targettokens);
		}
	}
	else if (currenttokens > targettokens && currenttokens % 2 != 0)
	{
		currenttokens += 25;
		cout << "By adding 25, you get " << currenttokens << ". " << endl;
		numturns--;
		if (currenttokens == targettokens)//if solution has been found
		{
			cout << "Path found with " << numturns << " turns left." << endl;
			return 0;
		}
		else //if solution has not been found
		{
			search(numturns, currenttokens, targettokens);
		}
	}
	else if (currenttokens < targettokens && currenttokens % 2 == 0)
	{
		currenttokens = currenttokens / 2;
		cout << "By dividing by 2 , you get " << currenttokens << "." << endl;
		numturns--;
		if (currenttokens == targettokens) //if solution has been found
		{
			cout << "Path found with " << numturns << " turns left." << endl;
			return 0;
		}
		else //if solution has not been found
		{
			search(numturns, currenttokens, targettokens);
		}
	}
	else if (currenttokens > targettokens && currenttokens % 2 == 0)
	{
		currenttokens = currenttokens / 2;
		cout << "By dividing by 2, you get " << currenttokens << "." << endl;
		numturns--;
		if (currenttokens == targettokens) //if solution has been found
		{
			cout << "Path found with " << numturns << " turns left." << endl;
			return 0;
		}
		else //if solution has not been found
		{
			search(numturns, currenttokens, targettokens);
		}
	}
}


