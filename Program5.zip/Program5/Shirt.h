#pragma once
#include"Product.h"

class Shirt : public Product {
public:
	//default constructor
	Shirt();
	Shirt(string s);
	//setters
	void setSize(string s);
	//overridden print
	void Print(ostream& line);
	//overridden calculateTotal
	double calculateTotal(); 
private:
	string size;
};