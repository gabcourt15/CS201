#include<string>
#include<iostream>
using namespace std;
#pragma once

class Product {
public:
	//default constructor
	Product();
	//other constructors
	Product(double p, int q);
	//setters
	void setPrice(double p);
	void setQuantity(int q);
	void setDescription(string d);
	//pure virtual function
	virtual void Print(ostream& line) = 0;
	//virtual function
	virtual double calculateTotal();
protected:
	double price;
	int quantity;
	string description;
};
