#pragma once
#include"Product.h"
#include"Shirt.h"
#include"OfficeSupplies.h"
class Register {
public:
	//default constructor
	Register();
	//functions
	void addProduct(Product* item);
	void printReceipt(ostream& out);

protected:
	Product *products[50];
	int numProducts;
};