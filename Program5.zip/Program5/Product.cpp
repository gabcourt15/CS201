#include"Product.h"

Product::Product()
{
	price = 0.0;
	quantity = 0;
}

Product::Product(double p, int q)
{
	price = p;
	quantity = q;
}

void Product::setPrice(double p)
{
	price = p;
}

void Product::setQuantity(int q)
{
	quantity = q;
}

void Product::setDescription(string d)
{
	description = d;
}

double Product::calculateTotal()
{
	return price * quantity;
}