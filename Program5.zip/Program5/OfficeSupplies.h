#pragma once
#include"Product.h"

class OfficeSupplies :public Product {
public:
	OfficeSupplies();
	OfficeSupplies(int c);
	//setters
	void setCount(int c);
	//overridden print 
	void Print(ostream& line);
protected:
	int count;
};