#include"Register.h"
#include"Shirt.h"
#include"OfficeSupplies.h"

Register::Register()
{
	numProducts = 0;
}

void Register::addProduct(Product*  item)
{
	products[numProducts] = item; //add item to array
	numProducts++; //increase number of items in array
}

void Register::printReceipt(ostream& out)
{
	for (int i = 0; i < 40; i++) //output 40 stars
	{
		out << "*";
	}
	out << endl << "*" << "            " << "UMKC BOOKSTORE" << "            " << "*" << endl; //output bookstore name
	for (int i = 0; i < 40; i++) //output 40 more stars
	{
		out << "*";
	}
	out << endl;
	out << "Qty Description                 Total" << endl; //output header
	out << "--- --------------------------- --------" << endl;
	for (int i = 0; i < numProducts; i++) //output each item bought and its total 
	{
		products[i]->Print(out);
		out << endl;
	}
	out << endl;
	out << "Grand Total: ";
	double total = 0.0;
	for (int i = 0; i < this->numProducts; i++) //add each item total together to get grand total
	{
		total += this->products[i]->calculateTotal();
	}
	out << total << endl;
	out << "Items Sold: " << this->numProducts << endl;
}