#include"Shirt.h"
#include<iomanip>

Shirt::Shirt()
{
	size = "S";
}

Shirt::Shirt(string s)
{
	size = s;
}
void Shirt::setSize(string s)
{
	size = s;
}

void Shirt::Print(ostream& line)
{
	line << right << setw(3) << quantity;
	line << " " << size << " " << description << left << setw(12);
	line << right<< "$" << setw(7) << calculateTotal() << endl;
}

double Shirt::calculateTotal()
{
	if (size == "2XL" || size == "3XL")
	{
		return (price + 1) * quantity;
	}
	else
		return price * quantity;
}