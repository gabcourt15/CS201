#include"Product.h"
#include"Shirt.h"
#include"OfficeSupplies.h"
#include"Register.h"
#include<iostream>
#include<fstream>
#include<string>
using namespace std;

void main() {
	//establishing file streams
	ifstream in;
	ofstream out;

	//opening files
	in.open("products.txt");
	out.open("receipt.txt");

	//declaring variables
	string item, d, size;
	int q, c;
	double p;
	Register r;


	//make sure files open correctly
	if (in.fail())
	{
		cout << "The file could not be opened.";
	}
	if (out.fail())
	{
		cout << "The file could not be opened.";
	}

	//while file has data
	while (!in.eof())
	{
		getline(in, item); //read in item
		if (item == "SHIRT")
		{
			getline(in, d);
			getline(in, size);
			Product *sp = new Shirt(size); //create new item
			in >> q;
			in >> p;
			sp->setDescription(d); //set its values
			sp->setPrice(p);
			sp->setQuantity(q);
			r.addProduct(sp); //add the item to the array
		}
		if (item == "SUPPLIES")
		{
			getline(in, d);
			in >> c;
			Product *op = new OfficeSupplies(c); //create new item
			in >> q;
			in >> p;
			op->setDescription(d); //set its values
			op->setPrice(p);
			op->setQuantity(q);
			r.addProduct(op); //add the item to the array
		}
	}
	r.printReceipt(out); //print the recipt
}
