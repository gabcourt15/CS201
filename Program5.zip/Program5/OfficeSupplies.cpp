#include"OfficeSupplies.h"
#include<iomanip>

OfficeSupplies::OfficeSupplies()
{
	count = 0;
}

OfficeSupplies::OfficeSupplies(int c)
{
	count = c;
}

void OfficeSupplies::setCount(int c)
{
	count = c;
}

void OfficeSupplies::Print(ostream& line)
{
	line << right << setw(3) << quantity;
	line << " " << description << " (" << count << " count" << ")" << left << setw(9);
	line <<right  << "$" << setw(7) << calculateTotal() << endl;
}
