//Gabby Courtney
//Program I
// Due 09/04/2016

#include<iostream>
#include<cmath>
using namespace std;

//function declaration
float withdraw(float balance);
//Precondition: The function will take in the current balance
//Postcondition: Based on user input, the amount withdrawn will be subtracted from the current balance
float deposit(float balance);
//Precondition: The function will take in the current balance
//Postcondition: Based on user input, the amount deposited will be added to the current balance
float monthly_payment(float loan_amount, int credit_score, float interest_rate, int num_months);
//Precondition: The function will take in the loan amount, credit score, interest rate and number of months
//Postcondition: Based on the user input, the function will calculate the monthly payment for a loan.

int main()
{
	int choice;
	float balance = 10000;
	bool transaction_loop = true;
	int transaction_choice;
	do
	{
		std::cout << "Would you like to 1. withdraw, 2. deposit or 3. take out a loan?\n";
		cin >> choice; //what does the user want to do?
		if (choice <= 0 || choice > 3)
		{
			std::cout << "Oh, so you don't want to make a transaction?\n";
		}
		else if (choice == 1) 
		{
			balance = withdraw(balance); //run withdraw function to withdraw money
			std::cout << "Your current balance is " << balance << endl;
		}
		else if (choice == 2)
		{
			balance = deposit(balance); //run deposit function to deposit money
			std::cout << "Your current balance is " << balance << endl;
		}
		else if (choice == 3)
		{
			int credit_score, num_months;
			float interest_rate, monthpayment, loan_amount;
			bool loan_loop = true, credit_loop = true, month_loop = true;
			while (loan_loop == true)
			{
				try
				{
					std::cout << "How much money would you like to borrow? ";
					cin >> loan_amount;
					if (loan_amount <= 0)
					{
						throw loan_amount;
					}
					else if (loan_amount > 0) //loan amount must be valid
					{
						loan_loop = false;
					}
				}
				catch (float loan_amount)
				{
					std::cout << "You cannot take out a loan for " << loan_amount << " dollars. \n";
				}
			}
			while (credit_loop == true)
			{
				try
				{
					std::cout << "What is your credit score? ";
					cin >> credit_score;
					if (credit_score < 0) //credit scores cannot be negative
					{
						throw credit_score;
					}
					else if (credit_score >= 0 && credit_score <= 500)
					{
						interest_rate = .05;
						credit_loop = false;
					}
					else if (credit_score > 500 && credit_score < 700)
					{
						interest_rate = .02;
						credit_loop = false;
					}
					else if (credit_score >= 700)
					{
						interest_rate = .01;
						credit_loop = false;
					}
				}
				catch (int credit_score)
				{
					std::cout << "Your credit score cannot be less than 0. " << endl;
				}
			}
			std::cout << "Your interest rate for the loan will be " << (interest_rate * 100) << "%.\n";
			while (month_loop == true)
			{
				try
				{
					std::cout << "How many months will you take to payoff the loan? ";
					cin >> num_months;
					if (num_months <= 0) //a loan takes more than one month to pay off
					{
						throw num_months;
					}
					else if (num_months > 0)
					{
						month_loop = false;
					}
				}
				catch (int num_months)
				{
					std::cout << "You must take more than one month to pay off the loan." << endl;
				}
			}
			monthpayment = monthly_payment(loan_amount, credit_score, interest_rate, num_months); //run monthly_payment function to calculate payment for loan
			std::cout << "Your monthly payment will be " << monthpayment << endl;
		}
		try
		{
			std::cout << "Would you like to make another transaction? 1. Yes or 2. No"; //another transaction?
			cin >> transaction_choice;
			if (transaction_choice == 2)
			{
				transaction_loop = false;
			}
			else if (transaction_choice <= 0 || transaction_choice >2) //choice must be one or two
			{
				throw transaction_choice;
			}
		}
		catch (int transaction_choice)
		{
			std::cout << "You must enter 1 or 2\n";
		}
	} while (transaction_loop == true);
}

//function definition
float withdraw(float balance)
{
	float withdraw_amount;
	try
	{
		std::cout << "How much money would you like to withdraw?  Your current balance is " << balance << endl;
		cin >> withdraw_amount;
		if (withdraw_amount <= balance && withdraw_amount > 0) //valid amount was entered
		{
			balance -= withdraw_amount;
			std::cout << "You have withdrawn " << withdraw_amount << endl;
		}
		else if (withdraw_amount > balance || withdraw_amount <= 0) //withdraw amount must be less than balance but more than 0
		{
			throw withdraw_amount;
		}
	}
	catch (float withdraw_amount)
	{
		std::cout << "You must enter a valid amount of money to withdraw. \n";
	}

	return balance;
}

float deposit(float balance)
{
	float deposit_amount;
	try
	{
		std::cout << "How much money would you like to deposit? Your current balance is " << balance << endl;
		cin >> deposit_amount;
		if (deposit_amount > 0) //valid amount was entered
		{
			balance += deposit_amount;
			std::cout << "You have deposited " << deposit_amount << " dollars into your account \n";
		}
		else if (deposit_amount <= 0) //deposits must be greater than 0
		{
			throw deposit_amount;
		}
	}
	catch (float deposit_amount)
	{
		std::cout << "You must enter a valid amount to deposit. \n";
	}
	return balance;
}

float monthly_payment(float loan_amount, int credit_score, float interest_rate, int num_months)
{
	float mod_interest, exponent_interest, interest_times_principal, monthpayment; //calculates monthly payment based on given formaula
	mod_interest = interest_rate + 1; 
	exponent_interest = pow(mod_interest, (num_months / 12));
	interest_times_principal = loan_amount * exponent_interest;
	monthpayment = interest_times_principal / num_months;
	return monthpayment;
}